# Finn

Personal portfolio intelligence system — an AI co-pilot for an active, concentrated AI/semiconductor growth portfolio. This repo is the **canonical home** for Finn's state, system definition, skill modules, visual standard, and the cockpit app.

> Personal tooling. Not investment advice.

## Canonical rule

Files in this repo are the single source of truth. Conversational memory is a thin pointer only — if memory and a file disagree, **the file wins**. `FINN_STATE.json` is the read-first entry point; `FINN_SYSTEM_PROMPT.md` is the lean operating core.

## File map

| File | What it is |
|---|---|
| `FINN_STATE.json` | **Read first.** All portfolio + per-ticker DATA: anchors, positions, trades, scores, NAV history, watchlist, earnings, thesis, reviews, macro, gameplan, session handoff. |
| `FINN_SYSTEM_PROMPT.md` | **Lean core** (v3.0) — identity, core + meta rules, command index, module map, data pointers. Procedures live in `skills/`. |
| `skills/` | 8 skill modules (`<name>/SKILL.md`) — load on demand: `fmp-feed`, `scoring`, `monitoring`, `frameworks`, `daily-surfaces`, `report-surfaces`, `sync`, `visual-system`. |
| `FINN_VISUAL_SYSTEM_v3_3.html` | v3.3 visual standard — design tokens + component library. Source of truth for `skills/visual-system`. |
| `FINN_DASH_TEMPLATE_v3_2.html` | Dashboard template (backfill to v3.3 pending). |
| `FINN_SESSION_HANDOFF_TEMPLATE.md` | Session handoff template. |
| `FINN_SYNC.md` | Git workflow — how state changes flow to commits (replaces the upload dance). |
| `TODO.md` | Living workstream / build checklist. |
| `finn_cockpit.jsx` | The Finn Cockpit (Phase 1) — React artifact: live FMP via MCP, `window.storage` persistence, v3.3 UI. |
| `.gitignore` | deps / secrets / build output. |

## How the skills work

The core stays small and always-on. Each skill is one job — "how the FMP feed works," "how to render a dash," "how to score a name." In **Claude Code / the Claude apps** skills auto-load by their description; in a **plain Project**, the core points to them and Finn reads `skills/<name>/SKILL.md` before rendering the matching surface. Either way, the *values* live in `FINN_STATE.json` — the skills hold method and format, never ticker data.

## Workflow

See `FINN_SYNC.md`. On any change → edit the file + commit (decision = file updated, same step). GMF = pull latest. GNF = commit touched files + push.

## Build roadmap

1. ✅ **Phase 1 — In-chat cockpit** (`finn_cockpit.jsx`)
2. ✅ **GitHub foundation** — this repo
3. ✅ **Skills refactor** — lean core + 8 modules, data deduped to `FINN_STATE.json`
4. ⬜ **Phase 2 — Claude Design** — design the full platform, hand off to Code
5. ⬜ **Phase 3 — Claude Code** — deployed Next.js app on live data

## Running the cockpit

`finn_cockpit.jsx` is a Claude artifact (React) — it runs in the Claude.ai artifact viewer, pulls live quotes from FMP via MCP, persists via `window.storage`, and is seeded from `FINN_STATE.json`.
