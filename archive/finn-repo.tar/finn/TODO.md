# Finn — TODO / Workstream

Living checklist. (Moved out of the system prompt in v3.0.)

## HIGH PRIORITY
- [ ] **TRACK 2 — DATA SPEC:** go location-by-location through every command-center surface + define WHAT data populates each (visual standard = HOW it shows; this = WHAT). Per location: FIELDS · SOURCE (file / FMP endpoint) · REFRESH cadence · TRIGGER LOGIC / thresholds. Start at home (status strip; action-queue trigger rules; command-bar suggestions; jump chips; flight-deck most-used logic; fired-today auto-fire; tiles + feed badges), then dash + all surfaces.
- [ ] **TRACK 1 — VISUAL LIBRARY remaining:** extends the 8 locked components. P1: Panel + section-header · Chrome/breadcrumb bar · Table (ledger / PT / trade-log / impact). P2: Bar/meter (CS/MS dual, progress, allocation) · Sparkline (NAV curve) · Empty/loading/feed-down/price-UNCONFIRMED states. P3: scenario card · week timeline · focus card · iconography + motion. Lock each vs the visual standard → codify into FINN_VISUAL_SYSTEM_v3_3.html.
- [ ] ORDER: Track 2 first from the home status strip; pull Track 1 P1 (Panel/Chrome/Table) in as they surface.
- [ ] v3.3 Phase 3 backfill — normalize home / dash / guide / scenario to the standard (lowercase-mono command labels, control radius 8, one-primary-per-view).
- [ ] Button-route audit — tap each Control Center button, confirm it routes, lock each destination format.
- [ ] Dedicated formats: reviews / exit / rescore / NVDA sizing.
- [ ] Engine v3 · Ledger v3.
- [ ] Position sizing tool.
- [ ] Backtesting.
- [ ] APLD win review.
- [ ] Finn EXPORT — single shareable file.

## FRONTEND BUILD PROGRAM (5-step)
- [x] Phase 1 — in-chat cockpit (finn_cockpit.jsx)
- [x] Step 2 — GitHub foundation (this repo)
- [x] Step 3 — Skills refactor (this commit)
- [ ] Phase 2 — Claude Design (design the platform → Code handoff)
- [ ] Phase 3 — Claude Code (deployed Next.js app on live data)

## LOW PRIORITY
- [ ] Thesis doc · Risk doc · EXIT doc

## DEFERRED
- Quartr (transcripts) + LunarCrush (social) connectors — paid-gated. FMP is the sole feed.

## DONE (pre-refactor highlights)
Dash v3.1 · Visual v3.1–v3.3 · Exit v1 · Ledger v2 · Engine v2 · Cap-eff · Price widget · GMF/GNF · Trade grade · EOD · Gameplan · System · PT engine · FMP live feed (§FEED) + refresh chip + full data layer · Earnings tracker · Owned earnings + PT sweep · Control Center v1 · Live Watch v1 · Trade Log v1 · NAV Curve v1 · Watchlist earnings sweep (29 names) · NAV reconciled · Visual Standard v3.3 (tokens + 8 components) · Guide v1.1 · data consolidation (10 JSONs → FINN_STATE.json).
