---
name: scoring
description: Finn's CS/MS dual-rating and conviction-tier methodology. Use this whenever scoring or re-scoring a name, displaying CS or MS anywhere (cards, ledger, engine, radar, recs, alerts, stock reports), deciding or questioning a conviction tier, or whenever scores might be stale (>7 days old). Holds the CS and MS weight tables, the display rules, the silent-stale-rescore rule, and conviction-tier discipline. Consult before any rescore, stock report, ledger / engine / card render, or conviction change. Per-ticker scores and conviction values live in FINN_STATE.json — this skill is the method, not the data.
---

# Dual Rating System — CS + MS (/100)

Two scores per name. **CS (Company Score)** = business quality. **MS (Market Score)** = tradeability / momentum-weighted.

## CS (Company Score) weights
- Fundamentals: 38
- Moat: 22
- Momentum: 12
- Growth: 15
- Valuation: 8
- Portfolio Fit: 5

## MS (Market Score) weights
- Fundamentals: 28
- Moat: 15
- Momentum: 22
- Growth: 22
- Valuation: 8
- Portfolio Fit: 5

## Display rules
- Full words ("Company Score" / "Market Score") on cards / engine / radar / recs / alerts.
- Ledger = CS/MS numeric.
- Delta coloring: CS +8 = green · ±7 = neutral · MS +8 = amber.
- Tag every score render with "last scored [date]".
- **Stale rule:** score >7 days old → rescore silently BEFORE render, save to memory + FINN_STATE.json `scores` same response. Never display a stale score.
- Cadence: owned = weekly rescore; radar = on demand.

## Conviction tiers (1–5)
Conviction drives position sizing — higher conviction = larger size. Tiers: **5** (anchor / foundation) · **4** (core growth) · **3** (smaller / show-me).

**Tier discipline (hard):**
- Never change a conviction tier without explicit instruction.
- Tier change → update FINN_STATE.json `positions` + memory same response, and flag the sizing implication (a conviction bump usually means the position is now undersized → name the add zone).
- The per-ticker conviction list, CS/MS values, and score history are DATA — they live in **FINN_STATE.json** (`positions.conviction`, `positions.cs/ms`, `scores`). Read them from state; do not keep a copy here.

## Source tags
Reported fundamentals / earnings actuals / FMP consensus = `CONFIRMED`. Finn-derived numbers = `FINN PROJECTION`. Carry the visual-weight distinction (skills/visual-system Tag variant).
